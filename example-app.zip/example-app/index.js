window.onload = function(){
    // alert('Welcome to Concert Page')
    // Your javascript code comes here

    let form = document.querySelector("form")
    
    
    function getFormData(event){
        event.preventDefault()  
        // alert('Hi')
        const fullName = document.getElementsByName('full_name')[0].value
        const Nationality = document.getElementsByName('nationality')[0].value
        const age = document.getElementsByName('age')[0].value
        console.log(
            fullName,
            Nationality,
            age
        )
        displayData(fullName,Nationality,age)
        
    }

    function displayData(fullName,Nationality,age){

        const div = document.getElementById('data')
        // backtick operator to add dynamic html
        div.innerHTML = `
            <h3> Your Data </h3>
            <ul>
                <li> ${fullName} </li>
                <li> ${Nationality} </li>
                <li> ${age} </li>
            </ul>
        
        `
        // to pass dynamic variables use ${}


    }
    // 2 args - submit, function
    form.addEventListener("submit",getFormData)



    
}